from setuptools import setup

setup(name='vezamodule',
version='3.3.2', 
description='Все те функции и методы, что я использую в своей работе',
author='Овчинников Александр Николаевич',
py_modules=['vezamodule'])